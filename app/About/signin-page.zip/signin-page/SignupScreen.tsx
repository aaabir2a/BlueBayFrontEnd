"use client";

import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  SafeAreaView,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  agreeToTerms: boolean;
}

interface FormErrors {
  email?: string;
  password?: string;
}

const SignupScreen = ({ navigation }: any) => {
  const [formData, setFormData] = useState<FormData>({
    firstName: "Johnathon",
    lastName: "Doey",
    email: "abc@xyz.bom",
    password: "jhwg9g",
    agreeToTerms: false,
  });

  const [errors, setErrors] = useState<FormErrors>({
    email: "Please enter a valid email address",
    password: "Password must be 7 letters and 1 capital letter",
  });

  const [secureTextEntry, setSecureTextEntry] = useState(false);

  const handleSignup = () => {
    // Validation logic would go here
    console.log("Signup data:", formData);
  };

  const handleGoogleSignup = () => {
    console.log("Google signup");
  };

  const handleAppleSignup = () => {
    console.log("Apple signup");
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollView}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.content}>
            <Image
              source={require("../assets/images/safebox.png")}
              style={styles.walletImage}
              resizeMode="contain"
            />

            <Text style={styles.title}>Welcome to Piggybankr</Text>
            <Text style={styles.subtitle}>
              Share your details to create an account
            </Text>

            <View style={styles.form}>
              <View style={styles.nameContainer}>
                <TextInput
                  style={styles.nameInput}
                  value={formData.firstName}
                  onChangeText={(text) =>
                    setFormData({ ...formData, firstName: text })
                  }
                  placeholder="First name"
                />

                <TextInput
                  style={styles.nameInput}
                  value={formData.lastName}
                  onChangeText={(text) =>
                    setFormData({ ...formData, lastName: text })
                  }
                  placeholder="Last name"
                />
              </View>

              <View style={styles.inputContainer}>
                <View
                  style={[
                    styles.emailInputWrapper,
                    errors.email ? styles.inputError : null,
                  ]}
                >
                  <Ionicons
                    name="mail-outline"
                    size={20}
                    color={errors.email ? "#ff3b30" : "#777779"}
                    style={styles.inputIcon}
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Email"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    value={formData.email}
                    onChangeText={(text) => {
                      setFormData({ ...formData, email: text });
                      if (errors.email)
                        setErrors({ ...errors, email: undefined });
                    }}
                  />
                </View>
                {errors.email && (
                  <Text style={styles.errorText}>{errors.email}</Text>
                )}
              </View>

              <View style={styles.inputContainer}>
                <View
                  style={[
                    styles.passwordInputWrapper,
                    errors.password ? styles.inputError : null,
                  ]}
                >
                  <TextInput
                    style={styles.input}
                    placeholder="Password"
                    secureTextEntry={secureTextEntry}
                    value={formData.password}
                    onChangeText={(text) => {
                      setFormData({ ...formData, password: text });
                      if (errors.password)
                        setErrors({ ...errors, password: undefined });
                    }}
                  />
                  <TouchableOpacity
                    onPress={() => setSecureTextEntry(!secureTextEntry)}
                  >
                    <Ionicons
                      name={secureTextEntry ? "eye-outline" : "eye-off-outline"}
                      size={24}
                      color={errors.password ? "#ff3b30" : "#777779"}
                    />
                  </TouchableOpacity>
                </View>
                {errors.password && (
                  <Text style={styles.errorText}>{errors.password}</Text>
                )}
              </View>

              <View style={styles.termsContainer}>
                <TouchableOpacity
                  style={styles.checkbox}
                  onPress={() =>
                    setFormData({
                      ...formData,
                      agreeToTerms: !formData.agreeToTerms,
                    })
                  }
                >
                  {formData.agreeToTerms ? (
                    <View style={styles.checkedBox}>
                      <Ionicons name="checkmark" size={16} color="white" />
                    </View>
                  ) : (
                    <View style={styles.uncheckedBox} />
                  )}
                </TouchableOpacity>
                <Text style={styles.termsText}>
                  I agree to the{" "}
                  <Text
                    style={styles.termsLink}
                    onPress={() => console.log("Terms pressed")}
                  >
                    Terms & Conditions
                  </Text>
                </Text>
              </View>

              <TouchableOpacity
                style={[
                  styles.createButton,
                  !formData.agreeToTerms || Object.keys(errors).length > 0
                    ? styles.disabledButton
                    : null,
                ]}
                onPress={handleSignup}
                disabled={
                  !formData.agreeToTerms || Object.keys(errors).length > 0
                }
              >
                <Text style={styles.createButtonText}>Create an account</Text>
              </TouchableOpacity>

              <View style={styles.socialButtonsContainer}>
                <TouchableOpacity
                  style={styles.socialButton}
                  onPress={handleGoogleSignup}
                >
                  <Image
                    source={require("../assets/icons/google.png")}
                    style={styles.googleIcon}
                    resizeMode="contain"
                  />
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.socialButton}
                  onPress={handleAppleSignup}
                >
                  <Ionicons name="logo-apple" size={25} color="black" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <View style={styles.homeIndicator} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollView: {
    flexGrow: 1,
    paddingHorizontal: 24,
  },
  content: {
    flex: 1,
    alignItems: "center",
    paddingTop: 40,
    paddingBottom: 20,
  },
  walletImage: {
    width: 120,
    height: 120,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
    color: "#1d1d1f",
  },
  subtitle: {
    fontSize: 18,
    color: "#777779",
    marginBottom: 30,
    textAlign: "center",
  },
  form: {
    width: "100%",
  },
  nameContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  nameInput: {
    width: "48%",
    height: 56,
    backgroundColor: "#f6f6f6",
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    color: "#1d1d1f",
  },
  inputContainer: {
    marginBottom: 16,
  },
  emailInputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e2e2e2",
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 56,
  },
  passwordInputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: "#e2e2e2",
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 56,
  },
  inputError: {
    borderColor: "#ff3b30",
  },
  inputIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    height: 56,
    fontSize: 16,
    color: "#1d1d1f",
  },
  errorText: {
    color: "#ff3b30",
    fontSize: 14,
    marginTop: 4,
  },
  termsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 24,
    marginTop: 8,
  },
  checkbox: {
    marginRight: 8,
  },
  uncheckedBox: {
    width: 24,
    height: 24,
    borderWidth: 1,
    borderColor: "#777779",
    borderRadius: 4,
  },
  checkedBox: {
    width: 24,
    height: 24,
    backgroundColor: "#118c4f",
    borderRadius: 4,
    alignItems: "center",
    justifyContent: "center",
  },
  termsText: {
    fontSize: 16,
    color: "#1d1d1f",
  },
  termsLink: {
    color: "#118c4f",
  },
  createButton: {
    backgroundColor: "#118c4f",
    borderRadius: 8,
    height: 56,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 24,
  },
  disabledButton: {
    backgroundColor: "#e2e2e2",
  },
  createButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },
  socialButtonsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  socialButton: {
    width: "48%",
    height: 56,
    borderWidth: 1,
    borderColor: "#118c4f",
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  googleIcon: {
    width: 25,
    height: 25,
  },
  homeIndicator: {
    width: 134,
    height: 5,
    backgroundColor: "black",
    borderRadius: 2.5,
    alignSelf: "center",
    marginBottom: 8,
  },
});

export default SignupScreen;
