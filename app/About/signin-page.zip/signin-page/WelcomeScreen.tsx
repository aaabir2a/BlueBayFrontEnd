import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Dimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const { width } = Dimensions.get("window");

const WelcomeScreen = ({ navigation }: any) => {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.welcomeText}>Welcome to</Text>
          <Text style={styles.appName}>PiggyBankr</Text>
        </View>

        <View style={styles.imageContainer}>
          <Image
            source={require("~/assets/images/wallet.png")}
            style={styles.walletImage}
            resizeMode="contain"
          />
        </View>

        <View style={styles.paginationContainer}>
          <View style={[styles.paginationDot, styles.activeDot]} />
          <View style={styles.paginationDot} />
          <View style={styles.paginationDot} />
        </View>

        <TouchableOpacity
          style={styles.loginButton}
          onPress={() => navigation.navigate("Login")}
        >
          <Text style={styles.loginButtonText}>Login</Text>
          <Ionicons name="arrow-forward" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.createAccountButton}
          onPress={() => navigation.navigate("Signup")}
        >
          <Text style={styles.createAccountText}>
            or, <Text style={styles.createAccountLink}>Create an account</Text>
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.homeIndicator} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: "space-between",
    paddingTop: 60,
    paddingBottom: 20,
  },
  header: {
    alignItems: "center",
  },
  welcomeText: {
    fontSize: 28,
    color: "#1d1d1f",
    fontWeight: "400",
    textAlign: "center",
  },
  appName: {
    fontSize: 36,
    fontWeight: "bold",
    color: "#118c4f",
    textAlign: "center",
  },
  imageContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  walletImage: {
    width: 337,
    height: 361,
  },
  paginationContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 40,
  },
  paginationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#e2e2e2",
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: "#118c4f",
    width: 32,
    borderRadius: 4,
  },
  loginButton: {
    backgroundColor: "#118c4f",
    borderRadius: 8,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  loginButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "500",
    marginRight: 8,
  },
  createAccountButton: {
    alignItems: "center",
    marginBottom: 20,
  },
  createAccountText: {
    fontSize: 16,
    color: "#1d1d1f",
  },
  createAccountLink: {
    color: "#118c4f",
  },
  homeIndicator: {
    width: 134,
    height: 5,
    backgroundColor: "black",
    borderRadius: 2.5,
    alignSelf: "center",
    marginBottom: 8,
  },
});

export default WelcomeScreen;
