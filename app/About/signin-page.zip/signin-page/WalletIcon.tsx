import { View, StyleSheet } from "react-native";
import Svg, { Path, Rect } from "react-native-svg";

const WalletIcon = () => {
  return (
    <View style={styles.container}>
      <Svg width={80} height={80} viewBox="0 0 100 100">
        <Rect x="20" y="30" width="60" height="50" rx="5" fill="#5E5E5E" />
        <Rect x="25" y="25" width="50" height="40" rx="3" fill="#118c4f" />
        <Path d="M30 35 L45 35 L45 50 L30 50 Z" fill="#8CD9A9" />
        <Path d="M50 35 L65 35 L65 50 L50 50 Z" fill="#8CD9A9" />
        <Path d="M30 55 L65 55 L65 60 L30 60 Z" fill="#8CD9A9" />
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
});

export default WalletIcon;
